"use strict";
var Endabgabe;
(function (Endabgabe) {
    class moving {
        constructor() {
            this.cor = [];
            this.vel = [];
        }
    }
    Endabgabe.moving = moving;
})(Endabgabe || (Endabgabe = {}));
//# sourceMappingURL=moving.js.map